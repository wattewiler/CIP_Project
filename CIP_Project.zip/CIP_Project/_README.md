# CIP_Project
HSLU - MSc Applied Information and Data Science, CIP Group Project, Group 50
